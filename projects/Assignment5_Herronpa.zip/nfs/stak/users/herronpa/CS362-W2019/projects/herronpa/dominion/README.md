run make all #To compile the dominion code
run ./playdom 30 # to run playdom code

"make runrandomtests" will execute a compilation of all necessary
files and output for Assignment4

If you want to run each test individually, you can
"make runrandomtestcard1"
"make runrandomtestcard2"
"make runrandomtestadventurer"
